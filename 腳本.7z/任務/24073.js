var status = -1;

function start(mode, type, selection) {
	qm.sendNext("..!");
	qm.gainExp(5000);
	qm.forceCompleteQuest();
	qm.dispose();
}
function end(mode, type, selection) {
	qm.sendNext("..!");
	qm.gainExp(5000);
	qm.forceCompleteQuest();
	qm.dispose();
}
