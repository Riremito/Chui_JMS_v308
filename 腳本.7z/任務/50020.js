var status = -1;

function start(mode, type, selection) {
    cm.sendNext("Auf Haven the angel is defeated...");
    cm.forceCompleteQuest(50019);
    cm.forceStartQuest();
    cm.dispose();
}

function end(mode, type, selection) {
}