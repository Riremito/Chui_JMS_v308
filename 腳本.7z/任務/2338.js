var status = -1;

function start(mode, type, selection) {
	qm.gainItem(2430014,1);
	qm.forceCompleteQuest();
	qm.dispose();
}

function end(mode, type, selection) {
	qm.gainItem(2430014,1);
		qm.forceCompleteQuest();
		qm.dispose();
}
	