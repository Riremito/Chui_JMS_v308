var status = -1;

function start(mode, type, selection) {
	qm.sendNext("Oh, you already have monster book.");
	qm.forceCompleteQuest();
	qm.dispose();
}
function end(mode, type, selection) {
	qm.sendNext("Oh, you already have monster book.");
	qm.forceCompleteQuest();
	qm.dispose();
}
