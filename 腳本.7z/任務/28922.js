var status = -1;

function action(mode, type, selection) {

		qm.forceCompleteQuest();
	}


function end(mode, type, selection) {
qm.forceCompleteQuest();
}