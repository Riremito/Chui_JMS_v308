function start(mode, type, selection) {
    qm.forceStartQuest();
    qm.dispose();
}