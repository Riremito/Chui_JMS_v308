function start(mode, type, selection) {
    qm.gainItem(1142351, 1);
    qm.forceStartQuest();
    qm.forceCompleteQuest();
    qm.dispose();
}