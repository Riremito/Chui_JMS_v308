var status = -1;
//TEMPORARY QUEST NOW SKIPPING
//this quest is THIRD JOB ADV
function start(mode, type, selection) {
	qm.forceStartQuest();
	qm.forceCompleteQuest();
	qm.dispose();
}

function end(mode, type, selection) {
	qm.forceStartQuest();
	qm.forceCompleteQuest();
	qm.dispose();
}