var status = -1;

function start(mode, type, selection) {
	qm.sendNextPrev("If you want to capture a Jaguar, please talk to Black Jack.");
	qm.forceCompleteQuest();
	qm.safeDispose();
}

function start(mode, type, selection) {
	qm.sendNextPrev("If you want to capture a Jaguar, please talk to Black Jack.");
	qm.forceCompleteQuest();
	qm.safeDispose();
}