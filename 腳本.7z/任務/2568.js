var status = -1;

function start(mode, type, selection) {
	qm.warp(912060200,0);
	qm.gainItem(4033003, 1);
	qm.dispose();
}
function end(mode, type, selection) {
	qm.dispose();
}
