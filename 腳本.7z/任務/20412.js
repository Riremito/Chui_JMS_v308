var status = -1;

function start(mode, type, selection) {
                qm.warp(913070100,1);
                qm.dispose();
}