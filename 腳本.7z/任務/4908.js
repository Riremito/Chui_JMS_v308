var status = -1;

function start(mode, type, selection) {
	qm.forceCompleteQuest(4900);
	qm.forceCompleteQuest(4901);
	qm.forceCompleteQuest(4902);
	qm.forceCompleteQuest(4903);
	qm.forceCompleteQuest(4904);
	qm.forceCompleteQuest(4905);
	qm.forceCompleteQuest(4906);
	qm.forceCompleteQuest(4907);
	qm.forceCompleteQuest(4908);
	qm.forceCompleteQuest(4909);
	qm.forceCompleteQuest(4910);
	qm.forceCompleteQuest(4911);
	qm.gainExp(333 * 12);
	qm.dispose();
}

function end(mode, type, selection) {
	qm.forceCompleteQuest(4900);
	qm.forceCompleteQuest(4901);
	qm.forceCompleteQuest(4902);
	qm.forceCompleteQuest(4903);
	qm.forceCompleteQuest(4904);
	qm.forceCompleteQuest(4905);
	qm.forceCompleteQuest(4906);
	qm.forceCompleteQuest(4907);
	qm.forceCompleteQuest(4908);
	qm.forceCompleteQuest(4909);
	qm.forceCompleteQuest(4910);
	qm.forceCompleteQuest(4911);
	qm.gainExp(333 * 12);
	qm.dispose();
}