var status = -1;

function start(mode, type, selection) {
	qm.forceCompleteQuest();
}


function end(mode, type, selection) {
qm.dispose();
}