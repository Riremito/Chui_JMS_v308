/* Dawnveil
    [Halloween] Lord of Candy Check
	Cassandra
    Made by Daenerys
*/
var status = -1;

function start(mode, type, selection) {
		qm.dispose();
	}

function end(mode, type, selection) {
	   qm.dispose();		
}