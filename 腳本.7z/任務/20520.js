/*
 * Cygnus mount
 */

function start(mode, type, selection) {
    qm.gainItem(4032208, 1);
    qm.forceStartQuest();
}

function end(mode, type, selection) {
}