var status = -1;
//TEMPORARY QUEST NOW SKIPPING
//this quest is TENTH JOB ADV
function start(mode, type, selection) {
	qm.forceStartQuest();
	qm.forceCompleteQuest();
	qm.dispose();
}

function end(mode, type, selection) {
	qm.forceStartQuest();
	qm.forceCompleteQuest();
	qm.dispose();
}