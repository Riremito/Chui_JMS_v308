var status = -1;

//member of resistance.

function start(mode, type, selection) {
    qm.sendNext("Your third mission is to protect Surl.");
    qm.forceStartQuest();
    qm.forceCompleteQuest();
    qm.dispose();
}

function end(mode, type, selection) {
    qm.sendNext("Your third mission is to protect Surl.");
    qm.forceStartQuest();
    qm.forceCompleteQuest();
    qm.dispose();
}