var status = -1;

function start(mode, type, selection) {
	qm.sendNext("Thank you so much.");
	qm.forceCompleteQuest();
	qm.forceCompleteQuest(3186);
	qm.forceCompleteQuest(3187);
	qm.dispose();
}
function end(mode, type, selection) {
	qm.sendNext("Thank you so much.");
	qm.forceCompleteQuest();
	qm.forceCompleteQuest(3186);
	qm.forceCompleteQuest(3187);
	qm.dispose();
}
